COMBUSTION MODEL OF METHANE GAS AND COAL DUST

CODE DESCRIPTION: A one-dimensional mathematical model to describe phenomena of mass and heat transfer that occurs in an underground coal mine when an explosion occurs is described in the document. The document, which is self-contained, includes a description of the models implemented in python, lines of code, and an explanation of the lines of code developed; with the aim that this document is a tool versatile that can be easily understood and modified. The model seeks to represent a case of real life, which was the explosion that occurred in Boyaca in the municipality of Tasco, in which there is evidence of a coal dust and methane gas explosion. The code includes the model to describe the reactions that occur in the gas phase resulting from the combustion of coal and/or methane.

The code needs the Cantera installation to work properly, because the reactions in the gas phase relied on this open source software to consider detailed reaction mechanisms and adequate capture of intermediate species that are form in the combustion of any fuel.

Requires: Cantera >= 2.5.0, scipy >= 0.19, matplotlib >= 2.0

Web page to download Cantera:
https://cantera.org/install/index.html

Python Installation Tutorial - Cantera
https://docs.google.com/document/d/1BxFy7KprG8plF3rUA47otK4Bqy6x-rFxMMC28aeeyiw/edit?usp=sharing